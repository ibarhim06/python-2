# Create a function that takes a list of numbers and returns the largest number.
def find_largest_number(numbers):
    if not numbers:
        return None 
    largest = numbers[0] 
    for num in numbers:
        if num > largest:
            largest = num
    return largest


nums = [3, 7, 2, 9, 5]
print(f"The largest number in the list is: {find_largest_number(nums)}")
