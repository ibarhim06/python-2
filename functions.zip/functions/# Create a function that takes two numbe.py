# Create a function that takes two numbers and returns their sum.
def sum(num1,num2):
    return (num1 + num2)
num1=int(input("Enter a number :"))
num2=int(input("Enter a number :"))
print(sum(num1,num2))