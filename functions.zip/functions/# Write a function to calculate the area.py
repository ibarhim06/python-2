# Write a function to calculate the area of a circle given its radius.

def area_of_circle(radius):
    pi=3.14
    return pi *(radius**2)
radius=int(input("Enetr your radius :"))
print(area_of_circle(radius))