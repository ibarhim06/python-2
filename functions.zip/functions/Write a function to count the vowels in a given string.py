#Write a function to count the vowels in a given string.

def count_vowels(s):

    vowels = {'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'}

    count = 0

    for char in s:
        if char in vowels:
            count += 1
    return count


text = input("Enter a word")
print(f"Number of vowels in '{text}': {count_vowels(text)}")
