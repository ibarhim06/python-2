#Create a function that converts a given temperature from Celsius to Fahrenheit and vice versa.
def convert_temperature(value, scale):
    if scale.lower() == 'celsius':
        # Convert Celsius to Fahrenheit
        return (value * 9/5) + 32
    elif scale.lower() == 'fahrenheit':
        # Convert Fahrenheit to Celsius
        return (value - 32) * 5/9
    else:
        return "Invalid scale. Please use 'Celsius' or 'Fahrenheit'."

# Example usage:
celsius = 25
fahrenheit = 77
print(f"{celsius}° Celsius is {convert_temperature(celsius, 'celsius')}° Fahrenheit.")
print(f"{fahrenheit}° Fahrenheit is {convert_temperature(fahrenheit, 'fahrenheit')}° Celsius.")
