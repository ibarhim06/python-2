#Write a function to find the factorial of a number using recursion.

def factoial(n):
    if n==1 or n==0:
        return 1
    else:
        return n * factoial(n-1)
num=5
print(f"the factroial of {num} is {factoial(num)} ")