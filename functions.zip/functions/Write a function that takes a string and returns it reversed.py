#Write a function that takes a string and returns it reversed.
def reverse_string(number):
    return number[::-1]
number=input("enter a word :")
print(reverse_string(number))